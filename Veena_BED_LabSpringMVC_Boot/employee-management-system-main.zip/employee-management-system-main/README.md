# Simple Spring boot for Employee entity management
